#!/bin/bash
java -jar runScript.jar "/scratch/oracle/Oracle/Middleware/Oracle_Home"